//任务3：依赖关系（输出csv版本）
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DependencyAnalysis {
    private static final String CSV_FILE = "cli_dependency_analysis.csv";
    //如果是另外一个项目的话，文件名改成 CSV_FILE = "math_dependency_analysis.csv"

    public static void main(String[] args) {
        String projectPath = "C:/Users/13688/Desktop/程序分析/commons-cli";
        //如果是另外一个项目的话，地址改成 "C:/Users/13688/Desktop/程序分析/commons-math"
        try (FileWriter writer = new FileWriter(CSV_FILE)) {
            // 写入CSV文件表头
            writer.append("调用类名,被调用类名,调用次数\n");
            analyzeDependencies(projectPath, writer);
            System.out.println("CSV文件生成完成！");
        } catch (IOException e) {
            System.err.println("创建CSV文件时出错：" + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void analyzeDependencies(String path, FileWriter writer) {
        Map<String, Map<String, Integer>> dependencyMap = new HashMap<>();
        File file = new File(path);
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        analyzeDependencies(subFile.getAbsolutePath(), writer);
                    } else if (subFile.getName().endsWith(".java")) {
                        try {
                            JavaParser javaParser = new JavaParser();
                            var parseResult = javaParser.parse(subFile);
                            parseResult.ifSuccessful(cu -> {
                                for (ClassOrInterfaceDeclaration clazz : cu.findAll(ClassOrInterfaceDeclaration.class)) {
                                    String className = clazz.getNameAsString();
                                    for (MethodDeclaration method : clazz.getMethods()) {
                                        List<MethodCallExpr> methodCallExprList = method.findAll(MethodCallExpr.class);
                                        for (MethodCallExpr mce : methodCallExprList) {
                                            String calledClassName = mce.getName().getIdentifier();
                                            dependencyMap.putIfAbsent(className, new HashMap<>());
                                            dependencyMap.get(className).put(calledClassName, dependencyMap.get(className).getOrDefault(calledClassName, 0) + 1);
                                        }
                                    }
                                }
                            });
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        // 将依赖关系写入CSV文件
        for (Map.Entry<String, Map<String, Integer>> entry : dependencyMap.entrySet()) {
            String from = entry.getKey();
            Map<String, Integer> toMap = entry.getValue();
            for (Map.Entry<String, Integer> toEntry : toMap.entrySet()) {
                String to = toEntry.getKey();
                int count = toEntry.getValue();
                try {
                    writer.append(escapeCsvField(from)).append(",");
                    writer.append(escapeCsvField(to)).append(",");
                    writer.append(String.valueOf(count)).append("\n");
                } catch (IOException e) {
                    System.err.println("写入CSV文件时出错：" + e.getMessage());
                }
            }
        }
    }

    private static String escapeCsvField(String field) {
        if (field == null) return "";
        // 处理包含逗号、引号或换行符的字段
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            field = field.replace("\"", "\"\""); // 转义双引号
            return "\"" + field + "\""; // 用双引号括起来
        }
        return field;
    }
}