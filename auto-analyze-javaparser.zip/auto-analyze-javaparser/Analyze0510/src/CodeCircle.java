//任务4：代码度量（计算每个类中每个方法的圈复杂度）
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.WhileStmt;
import com.github.javaparser.ast.stmt.SwitchStmt;
import java.io.File;
import java.io.FileNotFoundException;

public class CodeCircle {
    public static void main(String[] args) {
        String projectPath = "C:/Users/13688/Desktop/程序分析/commons-math";
        //如果是另外一个项目的话，地址改成 "C:/Users/13688/Desktop/程序分析/commons-math"
        calculateCyclomaticComplexity(projectPath);
    }

    public static void calculateCyclomaticComplexity(String path) {
        File file = new File(path);
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        calculateCyclomaticComplexity(subFile.getAbsolutePath());
                    } else if (subFile.getName().endsWith(".java")) {
                        try {
                            JavaParser javaParser = new JavaParser();
                            var parseResult = javaParser.parse(subFile);
                            parseResult.ifSuccessful(cu -> {
                                for (ClassOrInterfaceDeclaration clazz : cu.findAll(ClassOrInterfaceDeclaration.class)) {
                                    for (MethodDeclaration method : clazz.getMethods()) {
                                        int complexity = 1;
                                        complexity += method.findAll(IfStmt.class).size();
                                        complexity += method.findAll(ForStmt.class).size();
                                        complexity += method.findAll(WhileStmt.class).size();
                                        complexity += method.findAll(SwitchStmt.class).size();
                                        System.out.println("类名: " + clazz.getNameAsString() + ", 方法名: " + method.getNameAsString() + ", 圈复杂度: " + complexity);
                                    }
                                }
                            });
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}