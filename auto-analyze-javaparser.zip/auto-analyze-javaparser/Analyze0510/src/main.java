//测试了一下javaparser官网上的入门案例，和任务关联性不大
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.Modifier;

public class main {
    public static void main(String[] args) {
        // 创建编译单元，代表一个Java源文件
        CompilationUnit compilationUnit = new CompilationUnit();
        // 在编译单元中添加一个名为MyClass的类，并设置为public
        ClassOrInterfaceDeclaration myClass = compilationUnit
                .addClass("MyClass")
                .setPublic(true);
        // 在MyClass类中添加一个public static修饰的int类型常量A_CONSTANT
        myClass.addField(int.class, "A_CONSTANT", Modifier.Keyword.PUBLIC, Modifier.Keyword.STATIC);
        // 在MyClass类中添加一个private修饰的String类型变量name
        myClass.addField(String.class, "name", Modifier.Keyword.PRIVATE);
        // 将构建的类转换为字符串形式，即生成对应的Java代码文本
        String code = myClass.toString();
        System.out.println(code);
    }
}