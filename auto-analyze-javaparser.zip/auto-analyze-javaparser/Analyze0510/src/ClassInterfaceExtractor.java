//任务1：类/接口汇总
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ClassInterfaceExtractor {
    private static final String CSV_FILE = "cli_class_interface_info.csv";
    //如果是另外一个项目的话，文件名改成 CSV_FILE = "math_class_interface_info.csv"

    public static void main(String[] args) {
        String projectPath = "C:/Users/13688/Desktop/程序分析/commons-cli";
        //如果是另外一个项目的话，地址改成 "C:/Users/13688/Desktop/程序分析/commons-math"
        File projectDir = new File(projectPath);

        if (!projectDir.exists()) {
            System.err.println("错误：指定的项目路径不存在：" + projectPath);
            return;
        }

        if (!projectDir.isDirectory()) {
            System.err.println("错误：指定的路径不是一个目录：" + projectPath);
            return;
        }

        try (FileWriter writer = new FileWriter(CSV_FILE)) {
            writer.append("类型,名称,包路径\n"); // 写入CSV表头
            System.out.println("开始分析项目：" + projectPath);
            System.out.println("结果将保存到：" + new File(CSV_FILE).getAbsolutePath());
            extractClassAndInterface(projectPath, writer);
            System.out.println("CSV文件生成完成！");
        } catch (IOException e) {
            System.err.println("创建CSV文件时出错：" + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void extractClassAndInterface(String path, FileWriter writer) {
        File file = new File(path);
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        extractClassAndInterface(subFile.getAbsolutePath(), writer);
                    } else if (subFile.getName().endsWith(".java")) {
                        try {
                            JavaParser javaParser = new JavaParser();
                            var parseResult = javaParser.parse(subFile);
                            parseResult.ifSuccessful(cu -> {
                                for (ClassOrInterfaceDeclaration clazz : cu.findAll(ClassOrInterfaceDeclaration.class)) {
                                    String type = clazz.isInterface() ? "接口" : "类";
                                    String name = clazz.getNameAsString();
                                    String packageName = cu.getPackageDeclaration()
                                            .map(p -> p.getNameAsString())
                                            .orElse("");

                                    try {
                                        // 写入CSV记录，处理可能包含逗号的特殊情况
                                        writer.append(type).append(",");
                                        writer.append(escapeCsvField(name)).append(",");
                                        writer.append(escapeCsvField(packageName)).append("\n");
                                    } catch (IOException e) {
                                        System.err.println("写入CSV文件时出错：" + e.getMessage());
                                    }
                                }
                            });
                        } catch (Exception e) {
                            System.err.println("处理文件时出错：" + subFile.getAbsolutePath());
                        }
                    }
                }
            }
        }
    }

    private static String escapeCsvField(String field) {
        if (field == null) return "";
        // 如果字段包含逗号或引号，用引号括起来并转义引号
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            field = field.replace("\"", "\"\""); // 转义双引号
            field = "\"" + field + "\""; // 用双引号括起来
        }
        return field;
    }
}