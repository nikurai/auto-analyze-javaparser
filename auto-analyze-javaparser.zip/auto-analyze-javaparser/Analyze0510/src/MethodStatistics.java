//任务2：方法统计
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MethodStatistics {
    private static final String CSV_FILE = "cli_method_statistics.csv";
    //如果是另外一个项目的话，文件名改成 CSV_FILE = "math_method_statistics.csv"

    public static void main(String[] args) {
        String projectPath = "C:/Users/13688/Desktop/程序分析/commons-cli";
        //如果是另外一个项目的话，地址改成 "C:/Users/13688/Desktop/程序分析/commons-math"
        try (FileWriter writer = new FileWriter(CSV_FILE)) {
            // 写入CSV文件表头
            writer.append("类名,方法名,行数,参数个数,类中方法数量\n");

            System.out.println("开始分析项目：" + projectPath);
            System.out.println("结果将保存到：" + new File(CSV_FILE).getAbsolutePath());

            Map<String, Integer> classMethodCountMap = new HashMap<>();
            analyzeMethods(projectPath, writer, classMethodCountMap);

            System.out.println("CSV文件生成完成！");
        } catch (IOException e) {
            System.err.println("创建CSV文件时出错：" + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void analyzeMethods(String path, FileWriter writer, Map<String, Integer> classMethodCountMap) {
        File file = new File(path);
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        analyzeMethods(subFile.getAbsolutePath(), writer, classMethodCountMap);
                    } else if (subFile.getName().endsWith(".java")) {
                        try {
                            JavaParser javaParser = new JavaParser();
                            var parseResult = javaParser.parse(subFile);
                            parseResult.ifSuccessful(cu -> {
                                for (ClassOrInterfaceDeclaration clazz : cu.findAll(ClassOrInterfaceDeclaration.class)) {
                                    String className = clazz.getNameAsString();
                                    int methodCount = classMethodCountMap.getOrDefault(className, 0);
                                    for (MethodDeclaration method : clazz.getMethods()) {
                                        int lineCount = method.getRange()
                                                .map(range -> range.end.line - range.begin.line + 1)
                                                .orElse(0);
                                        int paramCount = method.getParameters().size();
                                        String methodName = method.getNameAsString();

                                        methodCount++;
                                        classMethodCountMap.put(className, methodCount);

                                        try {
                                            // 写入CSV记录，转义特殊字符
                                            writer.append(escapeCsvField(className)).append(",");
                                            writer.append(escapeCsvField(methodName)).append(",");
                                            writer.append(String.valueOf(lineCount)).append(",");
                                            writer.append(String.valueOf(paramCount)).append(",");
                                            writer.append(String.valueOf(methodCount)).append("\n");
                                        } catch (IOException e) {
                                            System.err.println("写入CSV文件时出错：" + e.getMessage());
                                        }
                                    }
                                }
                            });
                        } catch (Exception e) {
                            System.err.println("处理文件时出错：" + subFile.getAbsolutePath());
                        }
                    }
                }
            }
        }
    }

    private static String escapeCsvField(String field) {
        if (field == null) return "";
        // 处理包含逗号、引号或换行符的字段
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            field = field.replace("\"", "\"\""); // 转义双引号
            return "\"" + field + "\""; // 用双引号括起来
        }
        return field;
    }
}