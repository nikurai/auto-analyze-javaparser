//任务4：代码度量（计算每个类的注释率）
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.comments.Comment;
import com.github.javaparser.ast.comments.JavadocComment;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CodeMetrics {
    private static final String CSV_FILE = "cli_code_metrics.csv";
    //如果是另外一个项目的话，文件名改成 CSV_FILE = "math_code_metrics.csv"

    public static void main(String[] args) {
        String projectPath = "C:/Users/13688/Desktop/程序分析/commons-cli";
        //如果是另外一个项目的话，地址改成 "C:/Users/13688/Desktop/程序分析/commons-math"
        calculateCommentRatio(projectPath);
    }

    public static void calculateCommentRatio(String path) {
        Map<String, ClassMetrics> classMetricsMap = new HashMap<>();
        traverseFiles(path, classMetricsMap);

        try (FileWriter writer = new FileWriter(CSV_FILE)) {
            // 写入CSV文件表头
            writer.append("类名,注释率,注释行数,总行数\n");

            for (Map.Entry<String, ClassMetrics> entry : classMetricsMap.entrySet()) {
                String className = entry.getKey();
                ClassMetrics metrics = entry.getValue();
                double commentRatio = (double) metrics.commentLines / metrics.totalLines * 100;

                // 写入CSV记录
                writer.append(className).append(",").append(String.format("%.2f", commentRatio)).append(",")
                        .append(String.valueOf(metrics.commentLines)).append(",").append(String.valueOf(metrics.totalLines))
                        .append("\n");
            }

            System.out.println("CSV文件生成完成！");
        } catch (IOException e) {
            System.err.println("创建CSV文件时出错：" + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void traverseFiles(String path, Map<String, ClassMetrics> classMetricsMap) {
        File file = new File(path);
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        traverseFiles(subFile.getAbsolutePath(), classMetricsMap);
                    } else if (subFile.getName().endsWith(".java")) {
                        analyzeJavaFile(subFile, classMetricsMap);
                    }
                }
            }
        }
    }

    private static void analyzeJavaFile(File file, Map<String, ClassMetrics> classMetricsMap) {
        JavaParser javaParser = new JavaParser(); // 创建JavaParser实例
        try {
            ParseResult<CompilationUnit> parseResult = javaParser.parse(file);
            parseResult.ifSuccessful(cu -> {
                for (ClassOrInterfaceDeclaration clazz : cu.findAll(ClassOrInterfaceDeclaration.class)) {
                    String className = clazz.getNameAsString();
                    ClassMetrics metrics = new ClassMetrics();

                    // 计算类的总行数
                    metrics.totalLines = clazz.getEnd().get().line - clazz.getBegin().get().line + 1;

                    // 计算类的注释行数
                    for (Comment comment : cu.getAllContainedComments()) {
                        if (isCommentInsideClass(comment, clazz)) {
                            metrics.commentLines += getCommentLineCount(comment);
                        }
                    }

                    classMetricsMap.put(className, metrics);
                }
            });
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static boolean isCommentInsideClass(Comment comment, ClassOrInterfaceDeclaration clazz) {
        int commentStart = comment.getBegin().get().line;
        int commentEnd = comment.getEnd().get().line;
        int classStart = clazz.getBegin().get().line;
        int classEnd = clazz.getEnd().get().line;
        return commentStart >= classStart && commentEnd <= classEnd;
    }

    private static int getCommentLineCount(Comment comment) {
        if (comment instanceof JavadocComment) {
            // Javadoc注释需要去除开始和结束标记
            String[] lines = comment.getContent().split("\n");
            return lines.length;
        }
        return comment.getEnd().get().line - comment.getBegin().get().line + 1;
    }

    private static class ClassMetrics {
        int totalLines = 0;
        int commentLines = 0;
        // 其他可能的指标可以在这里添加
    }
}