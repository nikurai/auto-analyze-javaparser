//任务4：代码度量（计算每个类的圈负责度总数）
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.WhileStmt;
import com.github.javaparser.ast.stmt.SwitchStmt;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

public class CodeTotal {
    public static void main(String[] args) {
        String projectPath = "C:/Users/13688/Desktop/程序分析/commons-cli";
        //如果是另外一个项目的话，地址改成 "C:/Users/13688/Desktop/程序分析/commons-math"
        calculateCyclomaticComplexity(projectPath);
    }

    public static void calculateCyclomaticComplexity(String path) {
        File file = new File(path);
        Map<String, Integer> classComplexityMap = new HashMap<>();
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        calculateCyclomaticComplexity(subFile.getAbsolutePath());
                    } else if (subFile.getName().endsWith(".java")) {
                        try {
                            JavaParser javaParser = new JavaParser();
                            ParseResult<CompilationUnit> parseResult = javaParser.parse(subFile);
                            parseResult.ifSuccessful(cu -> {
                                for (ClassOrInterfaceDeclaration clazz : cu.findAll(ClassOrInterfaceDeclaration.class)) {
                                    String className = clazz.getNameAsString();
                                    int classComplexity = 0;
                                    for (MethodDeclaration method : clazz.getMethods()) {
                                        int complexity = 1;
                                        complexity += method.findAll(IfStmt.class).size();
                                        complexity += method.findAll(ForStmt.class).size();
                                        complexity += method.findAll(WhileStmt.class).size();
                                        complexity += method.findAll(SwitchStmt.class).size();
                                        classComplexity += complexity;
                                    }
                                    classComplexityMap.put(className, classComplexity);
                                }
                            });
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        // 输出每个类的总的圈复杂度
        //System.out.println("每个类的总的圈复杂度：");
        for (Map.Entry<String, Integer> entry : classComplexityMap.entrySet()) {
            System.out.println("类名: " + entry.getKey() + ", 总的圈复杂度: " + entry.getValue());
        }
    }
}