//任务3：依赖关系（直接输出结果版本）
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DependencyAnalysis_tu {
    public static void main(String[] args) {
        String projectPath = "C:/Users/13688/Desktop/程序分析/commons-cli";
        //如果是另外一个项目的话，地址改成 "C:/Users/13688/Desktop/程序分析/commons-math"
        analyzeDependencies(projectPath);
    }

    public static void analyzeDependencies(String path) {
        Map<String, Map<String, Integer>> dependencyMap = new HashMap<>();
        File file = new File(path);
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    if (subFile.isDirectory()) {
                        analyzeDependencies(subFile.getAbsolutePath());
                    } else if (subFile.getName().endsWith(".java")) {
                        try {
                            JavaParser javaParser = new JavaParser();
                            var parseResult = javaParser.parse(subFile);
                            parseResult.ifSuccessful(cu -> {
                                for (ClassOrInterfaceDeclaration clazz : cu.findAll(ClassOrInterfaceDeclaration.class)) {
                                    String className = clazz.getNameAsString();
                                    for (MethodDeclaration method : clazz.getMethods()) {
                                        List<MethodCallExpr> methodCallExprList = method.findAll(MethodCallExpr.class);
                                        for (MethodCallExpr mce : methodCallExprList) {
                                            String calledClassName = mce.getName().getIdentifier();
                                            dependencyMap.putIfAbsent(className, new HashMap<>());
                                            dependencyMap.get(className).put(calledClassName, dependencyMap.get(className).getOrDefault(calledClassName, 0) + 1);
                                        }
                                    }
                                }
                            });
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
        // 打印依赖关系
        dependencyMap.forEach((from, toMap) -> {
            toMap.forEach((to, count) -> {
                System.out.println(from + " -> " + to + " : " + count);
            });
        });
    }
}